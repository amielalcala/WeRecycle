<?php
$db = mysqli_connect("localhost", "root", "", "werecycle");
date_default_timezone_set('Asia/Manila');
if (isset($_POST['register_btn'])){
  $usertype = "1";
  $firstname = $_POST['firstname'];
  $lastname = $_POST['lastname'];
  $email = $_POST['email'];
  $birthdate = $_POST['birthdate'];
  $barangay = $_POST['barangay'];
  $zip = $_POST['zip'];
  $street = $_POST['street'];
  $city = $_POST['city'];
  $username = $_POST['username'];
  $password = $_POST['password'];
  $rpassword = $_POST['rpassword'];
  $datecreated = date("Y/m/d h/i/sa");
  if ($password == $rpassword) {
    $password = md5($password);
   //validation down below
    $query="select * from user where (username='$username' or email='$email');";
            $res=mysqli_query($db,$query);
			if(mysqli_num_rows($res) > 0){
			 $row = mysqli_fetch_assoc($res);
			 if ($username==$row['username'])
            {
                echo "Username already exists";
            }
            elseif($email==$row['email'])
            {
                echo "Email already exists";
            }
			}else {
				$sql= "INSERT INTO `user` (`userID`, `usertypeID`, `username`, `password`, `lastname`, `firstname`, `street`, `barangay`, `city`, `zip`, `email`, `birthdate`, `pointsID`, `contactID`,`datecreated`) 
	VALUES (NULL, '$usertype', '$username', '$password', '$lastname', '$firstname', '$street', '$barangay', '$city', '$zip', '$email', '$birthdate', NULL, NULL,'$datecreated')";
	
    mysqli_query($db,$sql);
    header("location: Landing.php");
			}
   
	
  } else {
	  
  }
}
?>
<!DOCTYPE html>
<html>
  <head>
    <h2>Welcome to the registration page</h2>
  </head>
  <body>
    <form method="post" action="regDonor.php">
      <table>
        <tr>
          <td>First Name</td>
          <td><input type="text" name="firstname"/></td>
        </tr>

        <tr>
          <td>Last Name</td>
          <td><input type="text" name="lastname"/></td>
        </tr>

        <tr>
          <td>Email</td>
          <td><input type="email" name="email"/></td>
        </tr>

        <tr>
          <td>Birthday</td>
          <td><input type="date" name="birthdate"/></td>
        </tr>

        <tr>
          <td>Barangay</td>
          <td><input type="text" name="barangay"/></td>
        </tr>

        <tr>
          <td>Zip</td>
          <td><input type="number" name="zip"/></td>
        </tr>

        <tr>
          <td>Street</td>
          <td><input type="text" name="street"/></td>
        </tr>

        <tr>
          <td>City</td>
          <td><input type="text" name="city"/></td>
        </tr>

        <tr>
          <td>Username</td>
          <td><input type="text" name="username"/></td>
        </tr>

        <tr>
          <td>Password</td>
          <td><input type="password" name="password"/></td>
        </tr>

        <tr>
          <td>Repeat Password</td>
          <td><input type="password" name="rpassword"/></td>
        </tr>

        <tr>
          <td></td>
          <td><input type="submit" name="register_btn" value="Register"></td>
		</tr>
		<tr>
		<td></td>
		 <td><a href="Landing.php">Cancel</a></td>
		</tr>
      </table>
    </form>
  </body>
</html>