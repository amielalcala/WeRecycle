-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 21, 2018 at 05:46 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `werecycle`
--

-- --------------------------------------------------------

--
-- Table structure for table `auditlogs`
--

CREATE TABLE `auditlogs` (
  `auditlogID` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `date` datetime DEFAULT NULL,
  `activity` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auditlogs`
--

INSERT INTO `auditlogs` (`auditlogID`, `username`, `date`, `activity`) VALUES
(4, 'admin', '2018-08-21 11:20:27', 'Login'),
(5, 'cvreniel', '2018-08-21 11:43:27', 'Login');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `contactID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `cellNo` varchar(15) DEFAULT NULL,
  `tellNo` varchar(10) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `entry`
--

CREATE TABLE `entry` (
  `entryID` int(11) NOT NULL,
  `trashcategoryID` int(11) NOT NULL,
  `wastetypeID` int(11) NOT NULL,
  `kilos` int(11) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedbackID` int(11) NOT NULL,
  `userID` int(11) DEFAULT NULL,
  `feedback` varchar(100) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `points`
--

CREATE TABLE `points` (
  `pointsID` int(11) NOT NULL,
  `pointsaccumulated` int(11) DEFAULT NULL,
  `rewards` int(11) DEFAULT NULL,
  `userID` int(11) NOT NULL,
  `entryID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `productsID` int(11) NOT NULL,
  `requestID` int(11) DEFAULT NULL,
  `productname` varchar(50) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `recyclables`
--

CREATE TABLE `recyclables` (
  `recyclableID` int(11) NOT NULL,
  `entryID` int(11) NOT NULL,
  `requestID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `requestID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(50) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `trashcategory`
--

CREATE TABLE `trashcategory` (
  `trashcategoryID` int(11) NOT NULL,
  `categoryname` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userID` int(11) NOT NULL,
  `usertypeID` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(128) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `street` varchar(50) DEFAULT NULL,
  `barangay` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `zip` varchar(4) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `pointsID` int(11) DEFAULT NULL,
  `contactID` int(11) DEFAULT NULL,
  `datecreated` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userID`, `usertypeID`, `username`, `password`, `lastname`, `firstname`, `street`, `barangay`, `city`, `zip`, `email`, `birthdate`, `pointsID`, `contactID`, `datecreated`) VALUES
(5, 1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Castillo', 'Reniel ', '1320 sta.maria street', '54', 'Manila', '1002', 'cvreniel@gmail.com', '1998-02-04', NULL, NULL, '2018-08-21 00:00:00.000000'),
(6, 1, 'test', '098f6bcd4621d373cade4e832627b4f6', 'Valeroso', 'Ralph ', '1320 sta.maria street', '54', 'Manila', '1002', 'ralph@gmail.com', '1998-02-04', NULL, NULL, '2018-08-21 09:43:48.000000'),
(7, 1, 'cvreniel', 'e5fccd09c6d4a6f860a9a9e5f75fa11d', 'castillo', 'reniel', '1320 sta.maria street', '54', 'Manila', '1002', 'underkiller043@gmail.com', '1998-02-04', NULL, NULL, '2018-08-21 11:43:22.000000');

-- --------------------------------------------------------

--
-- Table structure for table `usertype`
--

CREATE TABLE `usertype` (
  `usertypeID` int(11) NOT NULL,
  `usertype` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usertype`
--

INSERT INTO `usertype` (`usertypeID`, `usertype`) VALUES
(1, 'Donor'),
(2, 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `wastetype`
--

CREATE TABLE `wastetype` (
  `wastetypeID` int(11) NOT NULL,
  `wastetype` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auditlogs`
--
ALTER TABLE `auditlogs`
  ADD PRIMARY KEY (`auditlogID`),
  ADD KEY `userID` (`username`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`contactID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `entry`
--
ALTER TABLE `entry`
  ADD PRIMARY KEY (`entryID`),
  ADD KEY `trashcategoryID` (`trashcategoryID`),
  ADD KEY `wastetypeID` (`wastetypeID`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedbackID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `points`
--
ALTER TABLE `points`
  ADD PRIMARY KEY (`pointsID`),
  ADD KEY `userID` (`userID`),
  ADD KEY `entryID` (`entryID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`productsID`),
  ADD KEY `requestID` (`requestID`);

--
-- Indexes for table `recyclables`
--
ALTER TABLE `recyclables`
  ADD PRIMARY KEY (`recyclableID`),
  ADD KEY `entryID` (`entryID`),
  ADD KEY `requestID` (`requestID`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`requestID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `trashcategory`
--
ALTER TABLE `trashcategory`
  ADD PRIMARY KEY (`trashcategoryID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `usertypeID` (`usertypeID`),
  ADD KEY `contactID` (`contactID`),
  ADD KEY `pointsID` (`pointsID`);

--
-- Indexes for table `usertype`
--
ALTER TABLE `usertype`
  ADD PRIMARY KEY (`usertypeID`);

--
-- Indexes for table `wastetype`
--
ALTER TABLE `wastetype`
  ADD PRIMARY KEY (`wastetypeID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auditlogs`
--
ALTER TABLE `auditlogs`
  MODIFY `auditlogID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `contactID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `entry`
--
ALTER TABLE `entry`
  MODIFY `entryID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedbackID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `points`
--
ALTER TABLE `points`
  MODIFY `pointsID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `productsID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `recyclables`
--
ALTER TABLE `recyclables`
  MODIFY `recyclableID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `requestID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trashcategory`
--
ALTER TABLE `trashcategory`
  MODIFY `trashcategoryID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `usertype`
--
ALTER TABLE `usertype`
  MODIFY `usertypeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `wastetype`
--
ALTER TABLE `wastetype`
  MODIFY `wastetypeID` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `contacts`
--
ALTER TABLE `contacts`
  ADD CONSTRAINT `contacts_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`);

--
-- Constraints for table `entry`
--
ALTER TABLE `entry`
  ADD CONSTRAINT `entry_ibfk_1` FOREIGN KEY (`trashcategoryID`) REFERENCES `trashcategory` (`trashcategoryID`),
  ADD CONSTRAINT `entry_ibfk_2` FOREIGN KEY (`wastetypeID`) REFERENCES `wastetype` (`wastetypeID`);

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`);

--
-- Constraints for table `points`
--
ALTER TABLE `points`
  ADD CONSTRAINT `points_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`),
  ADD CONSTRAINT `points_ibfk_2` FOREIGN KEY (`entryID`) REFERENCES `entry` (`entryID`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`requestID`) REFERENCES `request` (`requestID`);

--
-- Constraints for table `recyclables`
--
ALTER TABLE `recyclables`
  ADD CONSTRAINT `recyclables_ibfk_1` FOREIGN KEY (`entryID`) REFERENCES `entry` (`entryID`),
  ADD CONSTRAINT `recyclables_ibfk_2` FOREIGN KEY (`requestID`) REFERENCES `request` (`requestID`);

--
-- Constraints for table `request`
--
ALTER TABLE `request`
  ADD CONSTRAINT `request_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_2` FOREIGN KEY (`contactID`) REFERENCES `contacts` (`contactID`),
  ADD CONSTRAINT `user_ibfk_3` FOREIGN KEY (`pointsID`) REFERENCES `points` (`pointsID`),
  ADD CONSTRAINT `user_ibfk_4` FOREIGN KEY (`usertypeID`) REFERENCES `usertype` (`usertypeID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
